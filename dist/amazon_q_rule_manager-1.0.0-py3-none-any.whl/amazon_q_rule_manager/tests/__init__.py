"""Tests for Amazon Q Rule Manager."""
